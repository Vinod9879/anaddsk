﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webApitest.Migrations
{
    /// <inheritdoc />
    public partial class AddNewColumnsToOriginalECData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "AnyTransaction",
                table: "OriginalECData",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Extent",
                table: "OriginalECData",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsAlienated",
                table: "OriginalECData",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsCourtStay",
                table: "OriginalECData",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsGovtRestricted",
                table: "OriginalECData",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsMainOwner",
                table: "OriginalECData",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "LandType",
                table: "OriginalECData",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OwnerName",
                table: "OriginalECData",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OwnershipType",
                table: "OriginalECData",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 10, 3, 13, 45, 58, 84, DateTimeKind.Utc).AddTicks(4761), "$2a$11$lB7ewNqW6HQFk6tGc7sP4eA6I6wbO0PO7RR2dEui5cB/HM2Z3BCki" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AnyTransaction",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "Extent",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "IsAlienated",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "IsCourtStay",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "IsGovtRestricted",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "IsMainOwner",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "LandType",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "OwnerName",
                table: "OriginalECData");

            migrationBuilder.DropColumn(
                name: "OwnershipType",
                table: "OriginalECData");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 9, 28, 3, 50, 58, 431, DateTimeKind.Utc).AddTicks(6), "$2a$11$FE8eVnHYcp3MsQlKkuBRSeehBLyvONzdcDrRE40bke2wnyxs.8rBW" });
        }
    }
}
