﻿namespace DocumentVerificationDLL;

public class Class1
{

}
