﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webApitest.Migrations
{
    /// <inheritdoc />
    public partial class ChangeDOBToStringInOriginalTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Remarks",
                table: "OriginalECData",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 10, 3, 16, 3, 10, 206, DateTimeKind.Utc).AddTicks(7489), "$2a$11$axrPCSPXdrvL1ZcYe1jD9OLVq5UN51YWkiwmcnhurR5a6h9Shxgy2" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Remarks",
                table: "OriginalECData");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 10, 3, 13, 45, 58, 84, DateTimeKind.Utc).AddTicks(4761), "$2a$11$lB7ewNqW6HQFk6tGc7sP4eA6I6wbO0PO7RR2dEui5cB/HM2Z3BCki" });
        }
    }
}
