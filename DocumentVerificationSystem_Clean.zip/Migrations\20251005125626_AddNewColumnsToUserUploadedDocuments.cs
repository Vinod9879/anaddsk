﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace webApitest.Migrations
{
    /// <inheritdoc />
    public partial class AddNewColumnsToUserUploadedDocuments : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ExtractedData",
                table: "UserUploadedDocuments",
                type: "NVARCHAR(MAX)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsVerified",
                table: "UserUploadedDocuments",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<decimal>(
                name: "RiskScore",
                table: "UserUploadedDocuments",
                type: "decimal(5,2)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SurveyNumber",
                table: "UserUploadedDocuments",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VerificationStatus",
                table: "UserUploadedDocuments",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: true,
                defaultValue: "Pending");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 10, 5, 12, 56, 26, 418, DateTimeKind.Utc).AddTicks(5309), "$2a$11$.yL2PNRZ8HwuC4qEcrtyG.8pJfrsIHd/Kc7eImDCmW8E5ZG9pntWm" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExtractedData",
                table: "UserUploadedDocuments");

            migrationBuilder.DropColumn(
                name: "IsVerified",
                table: "UserUploadedDocuments");

            migrationBuilder.DropColumn(
                name: "RiskScore",
                table: "UserUploadedDocuments");

            migrationBuilder.DropColumn(
                name: "SurveyNumber",
                table: "UserUploadedDocuments");

            migrationBuilder.DropColumn(
                name: "VerificationStatus",
                table: "UserUploadedDocuments");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 10, 3, 16, 3, 10, 206, DateTimeKind.Utc).AddTicks(7489), "$2a$11$axrPCSPXdrvL1ZcYe1jD9OLVq5UN51YWkiwmcnhurR5a6h9Shxgy2" });
        }
    }
}
